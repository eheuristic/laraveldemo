<?php

class MailHistory extends Eloquent{
   protected $table = 'mail_history';
   
}

?>
