<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>{{$message->embedData($data, $subject)}}</title>
</head>

<body>
subject through message = {{$message->embedData($data, $subject)}}


</body>
</html>